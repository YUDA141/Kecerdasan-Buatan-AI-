<?php
require 'db.php';

// Ambil semua data training
$query = $conn->query("SELECT * FROM data_training");
$data_training = $query->fetch_all(MYSQLI_ASSOC);

$hasil = null;

// Proses prediksi jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputDiameter = (float)$_POST['diameter'];
    $inputTinggi   = (float)$_POST['tinggi'];

    // Fungsi untuk menghitung Euclidean Distance
    function euclideanDistance($d1, $t1, $d2, $t2) {
        return sqrt(pow($d1 - $d2, 2) + pow($t1 - $t2, 2));
    }

    // Hitung jarak ke semua data training
    $jarak = [];
    foreach ($data_training as $row) {
        $distance = euclideanDistance($inputDiameter, $inputTinggi, $row['diameter'], $row['tinggi']);
        $jarak[] = ['jarak' => $distance, 'jenis' => $row['jenis_pinus']];
    }

    // Urutkan berdasarkan jarak terdekat
    usort($jarak, fn($a, $b) => $a['jarak'] <=> $b['jarak']);

    // Ambil K terdekat (K = 3)
    $k = 3;
    $terdekat = array_slice($jarak, 0, $k);

    // Voting jenis paling banyak
    $vote = [];
    foreach ($terdekat as $row) {
        if (!isset($vote[$row['jenis']])) {
            $vote[$row['jenis']] = 0;
        }
        $vote[$row['jenis']]++;
    }
    arsort($vote);
    $hasil = array_key_first($vote);

    // Simpan ke data_uji
    $stmt = $conn->prepare("INSERT INTO data_uji (diameter, tinggi, hasil_prediksi) VALUES (?, ?, ?)");
    $stmt->bind_param("dds", $inputDiameter, $inputTinggi, $hasil);
    $stmt->execute();
}

// Ambil data uji untuk ditampilkan sebagai riwayat prediksi
$riwayat = $conn->query("SELECT * FROM data_uji ORDER BY id ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Prediksi Jenis Pinus</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <!-- Form Prediksi -->
            <div class="card shadow mb-4">
                <div class="card-header bg-success text-white">
                    <h4 class="mb-0">Prediksi Jenis Pinus</h4>
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Diameter (cm):</label>
                            <input type="number" step="any" name="diameter" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tinggi (m):</label>
                            <input type="number" step="any" name="tinggi" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Prediksi</button>
                        <a href="index.php" class="btn btn-danger">Kembali</a>
                    </form>

                    <?php if ($hasil): ?>
                        <div class="alert alert-info mt-4">
                            <strong>Hasil Prediksi:</strong> <?= htmlspecialchars($hasil) ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Riwayat Prediksi -->
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Riwayat Hasil Prediksi</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover mb-0">
                            <thead class="table-light text-center">
                                <tr>
                                    <th>ID</th>
                                    <th>Diameter (cm)</th>
                                    <th>Tinggi (m)</th>
                                    <th>Hasil Prediksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $riwayat->fetch_assoc()): ?>
                                <tr class="text-center">
                                    <td><?= $row['id'] ?></td>
                                    <td><?= $row['diameter'] ?></td>
                                    <td><?= $row['tinggi'] ?></td>
                                    <td><?= $row['hasil_prediksi'] ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Card -->
        </div>
    </div>
</div>

</body>
</html>

