<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sistem Prediksi Jenis Pinus</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center" style="min-height: 100vh;">

<div class="container text-center">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow p-4">
                <h1 class="mb-3 text-primary">Sistem Prediksi Jenis Pinus</h1>
                <p class="lead">Silakan pilih menu di bawah untuk mengelola data atau melakukan prediksi.</p>

                <div class="d-grid gap-3 col-6 mx-auto mt-4">
                    <a href="beranda.php" class="btn btn-success btn-lg">➕ Data Training (CRUD)</a>
                    <a href="berandap.php" class="btn btn-primary btn-lg">🔍 Prediksi Jenis Pinus</a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
