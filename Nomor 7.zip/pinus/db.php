<?php
$host     = "sql301.infinityfree.com";
$username = "if0_38930393";
$password = "yOqx8oUIv3bjUSY"; // kosongkan jika pakai XAMPP / Laragon
$database = "if0_38930393_pinus";

// Buat koneksi
$conn = new mysqli($host, $username, $password, $database);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}
?>
