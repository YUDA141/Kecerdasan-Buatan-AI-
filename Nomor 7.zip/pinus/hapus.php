<?php
require 'db.php';

$id = $_GET['id'];
$conn->query("DELETE FROM data_training WHERE id = $id");

header("Location: beranda.php");
exit;
