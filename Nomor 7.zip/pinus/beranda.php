<?php
require 'db.php';

// Ambil semua data training
$query = $conn->query("SELECT * FROM data_training");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Training - Prediksi Pinus</title>
    <!-- Link Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0">Data Training</h4>
            <div>
                <a href="tambah.php" class="btn btn-success btn-sm me-2">Tambah Data</a>
                <a href="index.php" class="btn btn-danger btn-sm">Kembali</a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead class="table-primary text-center">
                        <tr>
                            <th>ID</th>
                            <th>Diameter (cm)</th>
                            <th>Tinggi (m)</th>
                            <th>Jenis Pinus</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $query->fetch_assoc()): ?>
                        <tr class="text-center">
                            <td><?= $row['id'] ?></td>
                            <td><?= $row['diameter'] ?></td>
                            <td><?= $row['tinggi'] ?></td>
                            <td><?= $row['jenis_pinus'] ?></td>
                            <td>
                                <a class="btn btn-warning btn-sm" href="edit.php?id=<?= $row['id'] ?>">Edit</a>
                                <a class="btn btn-danger btn-sm" href="hapus.php?id=<?= $row['id'] ?>" onclick="return confirm('Yakin hapus data ini?')">Hapus</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

</body>
</html>
