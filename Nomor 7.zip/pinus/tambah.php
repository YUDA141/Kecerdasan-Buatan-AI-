<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $diameter = $_POST['diameter'];
    $tinggi = $_POST['tinggi'];
    $jenis = $_POST['jenis_pinus'];

    $stmt = $conn->prepare("INSERT INTO data_training (diameter, tinggi, jenis_pinus) VALUES (?, ?, ?)");
    $stmt->bind_param("dds", $diameter, $tinggi, $jenis);
    $stmt->execute();

    header("Location: beranda.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Data Training</title>
    <!-- Link Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Tambah Data Training</h4>
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Diameter (cm):</label>
                            <input type="number" step="any" name="diameter" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tinggi (m):</label>
                            <input type="number" step="any" name="tinggi" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Jenis Pinus:</label>
                            <input type="text" name="jenis_pinus" class="form-control" required>
                        </div>
                        <div class="d-flex justify-content-between">
                            <a href="beranda.php" class="btn btn-danger">Kembali</a>
                            <button type="submit" class="btn btn-success">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
