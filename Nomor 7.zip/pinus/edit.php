<?php
require 'db.php';

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM data_training WHERE id = $id");
$data = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $diameter = $_POST['diameter'];
    $tinggi = $_POST['tinggi'];
    $jenis = $_POST['jenis_pinus'];

    $stmt = $conn->prepare("UPDATE data_training SET diameter=?, tinggi=?, jenis_pinus=? WHERE id=?");
    $stmt->bind_param("ddsi", $diameter, $tinggi, $jenis, $id);
    $stmt->execute();

    header("Location: beranda.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Data Training</title>
    <!-- Link Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-warning">
                    <h4 class="mb-0">Edit Data Training</h4>
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Diameter (cm):</label>
                            <input type="number" step="any" name="diameter" value="<?= $data['diameter'] ?>" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tinggi (m):</label>
                            <input type="number" step="any" name="tinggi" value="<?= $data['tinggi'] ?>" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Jenis Pinus:</label>
                            <input type="text" name="jenis_pinus" value="<?= $data['jenis_pinus'] ?>" class="form-control" required>
                        </div>
                        <div class="d-flex justify-content-between">
                            <a href="beranda.php" class="btn btn-danger">Kembali</a>
                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>

